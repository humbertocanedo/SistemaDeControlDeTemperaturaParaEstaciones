const char* ssid     = "Tito cel";
const char* password = "12345678";

const char* hostname = "ESP8266_1";

IPAddress ip(172, 20, 10, 7);
IPAddress gateway(172, 20, 10, 1);
IPAddress subnet(255, 255, 255, 240);
